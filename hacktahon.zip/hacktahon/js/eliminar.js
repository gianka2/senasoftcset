function confirma_del(nom){
    var cad = "¿Desea borrar el registro: "+nom+"?";
    var respuesta = confirm(cad);
    if(respuesta == true){
      return true;
    }
    else{
      return false;
    }
  }