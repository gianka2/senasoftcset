// breakpoints
var BREAK = {
    LG: 1024,
    MD: 980,
    SM: 768,
    VS: 480,
    MN: 320
};