<?php
    require_once("view/login.phtml");
?>